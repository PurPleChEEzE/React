import BackButton from "../components/common/BackButton";

function RouterPage() {
    return (
        <>
            <p>라우터 테스트중</p>
            <BackButton />
        </>
    )
}

export default RouterPage;