import FormHandle from "../components/09_FormHandle"


export default function FormHandlePage() {
    return <FormHandle></FormHandle>
}