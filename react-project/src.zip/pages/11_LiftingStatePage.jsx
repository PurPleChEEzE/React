import LiftingChild from "../components/11_LiftingChild";
import StateChild from "../components/11_StateChild";

export default function LiftingStatePage2() {
    return (
        <>
            <p>테스트중</p>
            <LiftingChild></LiftingChild>
            <StateChild></StateChild>
        </>
    )
}