// p 태그 aobout page 입니다
// 뒤로가기버튼 o
// url : /Training/Aboutpage

import BackButton from "../../components/common/BackButton";

function AboutPage() {
    return (
        <>
            <p>About Page입니다</p>
            <BackButton />
        </>
    )
}

export default AboutPage;