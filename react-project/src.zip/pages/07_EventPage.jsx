import Event from "../components/07_Event";
import BackButton from "../components/common/BackButton";


export default function EventPage() {

    return (
        <>
            <Event />
            <BackButton />
        </>
    )

}