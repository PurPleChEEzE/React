import FreeList from "../../../components/board/free/FreeList"

export default function FreeListPage() {

    return (
        <>
            <FreeList></FreeList>
        </>
    )
}