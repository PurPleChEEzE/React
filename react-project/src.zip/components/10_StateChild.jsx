

export default function StateChild({ count }) {
    return (
        <>
            <h1>StateChild</h1>
            <p>현재 카운터 값 : {count}</p>
        </>
    )
}