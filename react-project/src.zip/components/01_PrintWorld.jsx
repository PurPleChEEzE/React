function PrintWorld() {
    return <p> Hello, World!</p>;
}

export default PrintWorld;